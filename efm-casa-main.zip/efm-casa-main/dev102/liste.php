<?php 

$id =  $_GET['id'];

echo "Vous avez choisi le produit".$id;

?>